@extends('layouts.navbar')
@section('content')
<div class="container-fluid custom-background">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="mt-4 text-white">
                <div class="mb-4">
                    <h1 class="text-justify" style="font-family: 'Roboto', sans-serif; color: #402515; font-size: 58px; font-weight: bold;" data-aos="fade-up" data-aos-anchor-placement="top-center">
                        Selamat Datang!
                    </h1>
                    <p class="text-justify" style="font-family: 'Roboto', sans-serif; color: #402515;" data-aos="fade-up" data-aos-anchor-placement="top-center">
                        Terima kasih telah menggunakan layanan kami.
                        Temukan fitur menarik kami dan nikmati pengalaman terbaik.
                        Silakan login untuk memulai atau jelajahi sebagai tamu.
                    </p>
                </div>
                <div id="myCarousel" class="carousel slide" data-ride="carousel" data-aos="fade-up" data-aos-anchor-placement="top-center">
                    <ol class="carousel-indicators">
                        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                        <li data-target="#myCarousel" data-slide-to="1"></li>
                        <li data-target="#myCarousel" data-slide-to="2"></li>
                    </ol>
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img src="{{ asset('/images/hm1.jpg') }}" alt="Gambar 1" style="width:100%;">
                        </div>
                        <div class="carousel-item">
                            <img src="{{ asset('/images/hm2.jpeg') }}" alt="Gambar 2" style="width:100%;">
                        </div>
                        <div class="carousel-item">
                            <img src="{{ asset('/images/hm3.jpg') }}" alt="Gambar 3" style="width:100%;">
                        </div>
                    </div>
                    <a class="carousel-control-prev" href="#myCarousel" data-slide="prev">
                        <span class="carousel-control-prev-icon"></span>
                    </a>
                    <a class="carousel-control-next" href="#myCarousel" data-slide="next">
                        <span class="carousel-control-next-icon"></span>
                    </a>
                </div>
                <div class="text-center mt-4">
                    @auth
                        <a href="{{ route('guest.ensiklopedia') }}" class="text-dark btn btn-danger">Mulai Ekspedisi</a>
                    @else
                        <a href="{{ route('user.login') }}" class="btn btn-danger">Login</a>
                    @endauth
                </div>
            </div>
        </div>
    </div>
</div>
@include('layouts.footer')
@endsection
<style>
    .custom-background {
        background-color: #DBCAB5;
        min-height: 100vh;
        padding: 20px;
    }
    .carousel-item {
    border-radius: 20px;
    overflow: hidden;
    }
</style>







