@extends('layouts.navbar')

@section('content')
<head>
    <script src="https://kit.fontawesome.com/2f5323979c.js" crossorigin="anonymous"></script>
</head>
<div class="container-fluid custom-background">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="mt-4 text-white">
                <div class="mb-4">
                    <h1 class="text-center" style="font-family: 'Roboto', sans-serif; color: #402515; font-size: 58px; font-weight: bold;">
                        <i class="fas fa-landmark" data-aos="fade-right"></i> Histopedia
                    </h1>         
                    <div class="mt-4 p-5 bg-warning text-dark rounded" data-aos="zoom-in">
                        <h1 >Selamat Datang di Histopedia</h1>
                        <p>Lorem ipsum...</p>
                    </div>
                    <div class="container mt-4">
                        <div class="input-group">
                            <input type="text" class="form-control border-0 rounded-pill" placeholder="Cari informasi..." style="background: rgba(238, 203, 87, 0.7);" id="searchInput">
                            <div class="input-group-append" style="display: flex;">
                                <button class="btn btn-danger rounded-pill align-self-end" type="button" id="searchButton">Search</button>
                            </div>
                        </div>
                    </div>
                    <div class="container mt-4" id="searchResults">
                    </div>
                    <script>
                        function createSearchCard(result) {
                            const resultCard = document.createElement('div');
                            resultCard.classList.add('card', 'mb-3');

                            const cardBody = document.createElement('div');
                            cardBody.classList.add('card-body');

                            const cardTitle = document.createElement('h5');
                            cardTitle.classList.add('card-title');
                            cardTitle.innerText = result.nama_situs;

                            const cardId = document.createElement('p');
                            cardId.classList.add('card-text');
                            cardId.innerText = `ID: ${result.id_situs}`;

                            const cardCategory = document.createElement('p');
                            cardCategory.classList.add('card-text');
                            cardCategory.innerText = `Kategori : ${result.jenis_situs}`;

                            const cardAddress = document.createElement('p');
                            cardAddress.classList.add('card-text');
                            cardAddress.innerText = `Alamat : ${result.alamat_situs}`;

                            const cardDate = document.createElement('p');
                            cardDate.classList.add('card-text');
                            cardDate.innerText = `Tanggal Berdiri : ${result.tanggal_berdiri_situs}`;

                            const cardOwner = document.createElement('p');
                            cardOwner.classList.add('card-text');
                            cardOwner.innerText = `Pemilik : ${result.pemilik_situs}`;

                            const cardDescription = document.createElement('p');
                            cardDescription.classList.add('card-text');
                            cardDescription.innerText = `Keterangan: ${result.keterangan_situs}`;

                            // Perbarui path gambar menggunakan asset helper
                            const imagePath = '{{ asset("storage/gambar") }}/' + result.gambar_situs;
                            const cardImage = document.createElement('img');
                            cardImage.classList.add('card-img-top', 'rounded');
                            cardImage.src = imagePath;
                            cardImage.alt = result.nama_situs;

                            cardBody.appendChild(cardImage);
                            cardBody.appendChild(cardTitle);
                            cardBody.appendChild(cardId);
                            cardBody.appendChild(cardCategory);
                            cardBody.appendChild(cardAddress);
                            cardBody.appendChild(cardDate);
                            cardBody.appendChild(cardOwner);
                            cardBody.appendChild(cardDescription);
                            
                            
                            resultCard.appendChild(cardBody);
                            return resultCard;
                        }
                        
                        function performSearch() {
                            const keyword = document.getElementById('searchInput').value.toLowerCase();
                            const searchResultsContainer = document.getElementById('searchResults');
                            searchResultsContainer.innerHTML = '';
                            const dataFromDatabase = {!! json_encode(\App\Models\SitusBersejarah::all()) !!};
                            const searchResults = dataFromDatabase.filter(result => 
                                result.id_situs.toLowerCase().includes(keyword) || result.nama_situs.toLowerCase().includes(keyword)
                            );
                            if (searchResults.length === 0) {
                                const noResultsMessage = document.createElement('p');
                                noResultsMessage.innerText = 'Tidak ada hasil yang sesuai dengan kata kunci.';
                                searchResultsContainer.appendChild(noResultsMessage);
                            } else {
                                searchResults.forEach(result => {
                                    const resultCard = createSearchCard(result);
                                    searchResultsContainer.appendChild(resultCard);
                                });
                            }
                        }
                        const searchButton = document.getElementById('searchButton');
                        searchButton.addEventListener('click', performSearch);
                    </script>
                    <h1 id="strukturOrganisasi" class="text-justify" style="font-family: 'Roboto', sans-serif; color: #402515; font-size: 58px; font-weight: bold;" data-aos="fade-right">
                        #Kategori yang anda mau!
                    </h1> 
                    <div class="container mt-5" data-aos="fade-up" data-aos-anchor-placement="top-center">
                        <div class="row justify-content-center">
                            <div class="col-md-3 mb-3">
                                <div class="card">
                                    <div class="card-body text-center">
                                        <h2 class="card-title">Arsitektur</h2>
                                        <i class="fa-solid fa-archway" style="font-size: 10em; display: block; margin: 0 auto;"></i>
                                        <a href="{{ route('guest.kategori.show', 'arsitektur') }}" class="btn btn-danger">
                                            <i class="fa fa-sign-in"></i> Kunjungi Halaman
                                        </a>                                                                                                                                                                                                  
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-3 mb-3">
                                <div class="card">
                                    <div class="card-body text-center">
                                        <h2 class="card-title">Bangunan</h2>
                                        <i class="fa-solid fa-building" style="font-size: 10em; display: block; margin: 0 auto;"></i>
                                        <a href="{{ route('kategori.show', 'bangunan') }}" class="btn btn-danger">
                                            <i class="fa fa-sign-in"></i> Kunjungi Halaman
                                        </a>  
                                    </div>
                                </div>
                            </div>
                    
                            <div class="col-md-3 mb-3">
                                <div class="card">
                                    <div class="card-body text-center">
                                        <h2 class="card-title">Monumen</h2>
                                        <i class="fa-solid fa-landmark" style="font-size: 10em; display: block; margin: 0 auto;"></i>
                                        <a href="{{ route('kategori.show', 'monumen') }}" class="btn btn-danger">
                                            <i class="fa fa-sign-in"></i> Kunjungi Halaman
                                        </a>  
                                    </div>
                                </div>
                            </div>
                        </div>
                    
                        <div class="row justify-content-center mt-3">
                            <div class="col-md-3 mb-3">
                                <div class="card">
                                    <div class="card-body text-center">
                                        <h2 class="card-title">Cagar Budaya</h2>
                                        <i class="fa-solid fa-map-location-dot" style="font-size: 10em; display: block; margin: 0 auto;"></i>
                                        <a href="{{ route('kategori.show', 'cagar') }}" class="btn btn-danger">
                                            <i class="fa fa-sign-in"></i> Kunjungi Halaman
                                        </a>  
                                    </div>
                                </div>
                            </div>
                    
                            <div class="col-md-3 mb-3">
                                <div class="card">
                                    <div class="card-body text-center">
                                        <h2 class="card-title">Benda</h2>
                                        <i class="fa-solid fa-mortar-pestle" style="font-size: 10em; display: block; margin: 0 auto;"></i>
                                        <a href="{{ route('kategori.show', 'benda') }}" class="btn btn-danger">
                                            <i class="fa fa-sign-in"></i> Kunjungi Halaman
                                        </a>  
                                    </div>
                                </div>
                            </div>
                    
                            <div class="col-md-3 mb-3">
                                <div class="card">
                                    <div class="card-body text-center">
                                        <h2 class="card-title">Situs Tak Benda</h2>
                                        <i class="fa-solid fa-tag" style="font-size: 10em; display: block; margin: 0 auto;"></i>
                                        <a href="{{ route('kategori.show', 'nonbenda') }}" class="btn btn-danger">
                                            <i class="fa fa-sign-in"></i> Kunjungi Halaman
                                        </a>  
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <br>
                    <br>
                    <h1 id="strukturOrganisasi" class="text-justify" style="font-family: 'Roboto', sans-serif; color: #402515; font-size: 58px; font-weight: bold;" data-aos="fade-right">
                        #Rekomendasi untuk anda!
                    </h1>                
                    <p class="text-justify" style="font-family: 'Roboto', sans-serif; color: #402515;" data-aos="fade-left">
                        Halo! penjelajah sejarah kota tapis berseri, disini kami berikan rekomendasi sejarah yang mungkin bisa kamu pelajari dan kunjungi.
                    </p>
                    <img data-aos="zoom-in" src="{{ asset('/images/hm1.jpg') }}" class="img-fluid mx-auto d-block rounded" style="max-width: 100%;" alt="Gambar Histopedia">
                    <br>
                    <br>
                    <h1 id="promosi" class="text-justify" style="font-family: 'Roboto', sans-serif; color: #402515; font-size: 58px; font-weight: bold;" data-aos="fade-right">
                        Jadi Kontributor!
                    </h1>
                    <p class="text-justify" style="font-family: 'Roboto', sans-serif; color: #402515;" data-aos="fade-left">
                        Dengan menjadi kontributor kamu berkontribusi dalam menyebarkan informasi sejarah dan menjaga sejarah di kota tercinta,
                        dengan beberapa syarat yang perlu kamu lengkapi kamu langsung bisa berkontribusi dalam menambahkan informasi terkait situs sejarah yang kamu ketahui.
                    </p>
                    <div class="container mt-4">
                        <div class="row justify-content-center">
                            @if(Auth::check())
                                <div class="col-md-4 text-center" data-aos="fade-up">
                                    <a href="{{ route('formulir') }}" class="btn btn-danger btn-lg btn-block">Ajukan Dokumen</a>
                                </div>
                                <div class="col-md-4 text-center" data-aos="fade-up">
                                    <a href="{{ route('formulir') }}" class="btn btn-danger btn-lg btn-block">Kontributor</a>
                                </div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@include('layouts.footer')
@endsection
<style>
    .custom-background {
        background-color: #DBCAB5;
        min-height: 100vh;
        padding: 20px;
    }
    .carousel-item {
    border-radius: 20px;
    overflow: hidden;
    }
</style>







