<!DOCTYPE html>
<html>
<head>
    <title>Dinas Kebudayaan Kota BandarLampung</title>
</head>
<body>
    <h1>{{ $mailData['title'] }}</h1>
    <p>{{ $mailData['body'] }}</p>
  
    <p>Bau lo</p>
     
    <p>Terimakasih</p>
</body>
</html>