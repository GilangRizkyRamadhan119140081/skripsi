@extends('layouts.navbar')

@section('navbar')
    <nav class="navbar navbar-expand-lg navbar-custom">
    </nav>
@endsection

@section('content')

<div class="container-fluid custom-background">
    <div class="bg-blue-200 py-8">
        <div class="container mx-auto">
            <div class="text-center">
                <h1 class="text-4xl font-semibold text-gray-800">Selamat Datang di Website Kami</h1>
                <p class="mt-2 text-lg text-gray-600">Website ini adalah tempat yang tepat untuk menemukan informasi menarik dan bermanfaat berkaitan dengan situs bersejarah di Kota Bandar Lampung.</p>
            </div>
        </div>
    </div>
    <div id="myCarousel" class="carousel slide" data-ride="carousel" data-aos="fade-up" data-aos-anchor-placement="top-center">
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="{{ asset('/images/landingpage.jpg') }}" alt="Gambar 1" class="d-block w-100">
            </div>
            <div class="carousel-item">
                <img src="{{ asset('/images/hm2.jpeg') }}" alt="Gambar 2" class="d-block w-100">
            </div>
            <div class="carousel-item">
                <img src="{{ asset('/images/hm3.jpg') }}" alt="Gambar 3" class="d-block w-100">
            </div>
        </div>
        <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
    <div class="bg-yellow-400 py-8">
        <div class="container mx-auto">
            <div class="text-center">
                <h2 class="text-2xl font-semibold text-gray-800">Siap untuk Memulai?</h2>
                <p class="mt-2 text-lg text-gray-600">Ayo mulai jelajahi website ini dengan mengaksesnya secara mudah dibawah ini!</p>
            </div>
        </div>
    </div>
    <div class="text-center mt-4">
        @auth
            <a href="{{ route('user.home') }}" class="btn btn-danger">Mulai Ekspedisi</a>
        @else
            <a href="{{ route('user.login') }}" class="btn btn-danger">Login</a>
            <a href="{{ route('guest.home') }}" class="btn btn-secondary">Guest</a>
        @endauth
    </div>
    <br>
</div>
@include('layouts.footer')
@endsection
<style>
    .custom-background {
        background-color: #DBCAB5;
        min-height: 100vh;
        padding: 20px;
    }
    .carousel-item {
        border-radius: 20px;
        overflow: hidden;
    }
    #myCarousel {
        max-width: 800px;
        margin: 0 auto; 
    }
</style>