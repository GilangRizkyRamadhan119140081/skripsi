<!DOCTYPE html>
<html lang="en">
<head>
    <!-- ... tag lain ... -->
    <link rel="stylesheet" href="{{ asset('css/footer.css') }}">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/2f5323979c.js" crossorigin="anonymous"></script>
</head>

<footer class="bg-gray-200 py-4">
    <div class="container-footer mx-auto">
        <div class="footer-content">
            <h3 class="text-sm font-semibold">Kontak Kami</h3>
            <p class="text-gray-700">Hubungi kami di:</p>
            <p class="text-gray-700">Telepon: 123-456-789</p>
            <p class="text-gray-700">Email: info@example.com</p>
        </div>
        <div class="footer-content">
            <h3 class="text-sm font-semibold">Ikuti Kami</h3>
            <ul class="text-gray-700">
                <li><i class="fa-brands fa-square-facebook"><a href="#"> Facebook</a></i></li>
                <li><i class="fa-brands fa-square-instagram"><a href="#"> Instagram</a></i></li>
                <li><i class="fa-brands fa-tiktok"><a href="#"> TikTok</a></i></li>
            </ul>
        </div>
    </div>
</footer>
</html>
