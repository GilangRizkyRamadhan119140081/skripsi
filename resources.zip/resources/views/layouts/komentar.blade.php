<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <style>
        /* Your custom CSS styles can be added here */
    </style>
</head>
<body>
<!-- Main Body -->
<section>
    <div class="container">
        <div class="row">
            <div class="col-sm-5 col-md-6 col-12 pb-4">
                <h1>Comments</h1>
            </div>
            <div class="col-lg-4 col-md-5 col-sm-4 offset-md-1 offset-sm-1 col-12 mt-4">
                <form id="align-form" action="{{ route('komentar.store', ['pageId' => $situs->id_situs]) }}" method="POST">

                    @csrf
                    <div class="form-group">
                        <h4>Leave a comment</h4>
                        <label for="komentar">Comment</label>
                        <textarea name="komentar" id="komentar" cols="30" rows="5" class="form-control" style="background-color: rgb(255, 255, 255);"></textarea>
                    </div>
                    <!-- Add a hidden input field for situs_id -->
                    <input type="hidden" name="page_id" value="{{ $situs->id_situs }}">
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" name="name" id="fullname" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="text" name="email" id="email" class="form-control">
                    </div>
                    <div class="form-group">
                        <p class="text-secondary">If you have a <a href="#" class="alert-link">Gravatar account</a> your address will be used to display your profile picture.</p>
                    </div>
                    <div class="form-check">
                        <input type="checkbox" name="subscribe" id="subscribe" class="form-check-input">
                        <label for="subscribe" class="form-check-label">Subscribe me to the newsletter</label>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">Post Comment</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
</body>
</html>
