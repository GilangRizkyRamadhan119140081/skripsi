@extends('layout.app')

@section('title', 'Daftar Pengajuan')

@section('content')
    <h1>Daftar Pengajuan</h1>
    <a href="{{ route('admin.progres.create') }}" class="btn btn-primary mb-3">Tambah Progres</a>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Nama</th>
                <th>Instansi</th>
                <th>Email</th>
                <th>Alamat</th>
                <th>Nomor HP</th>
                <th>Jenis Keperluan</th>
                <th>Keterangan</th>
                <th>Surat Perizinan</th>
                <th>Gambar</th>
                <th>Status</th>
                <th>Download</th>
                <th>Aksi</th>

            </tr>
        </thead>
        <tbody>
            @foreach ($formulirs as $formulir)
                <tr>
                    <td>{{ $formulir->nama }}</td>
                    <td>{{ $formulir->instansi }}</td>
                    <td>{{ $formulir->email }}</td>
                    <td>{{ $formulir->alamat }}</td>
                    <td>{{ $formulir->nomor_hp }}</td>
                    <td>{{ $formulir->jenis_keperluan }}</td>
                    <td>{{ $formulir->keterangan }}</td>
                    <td>
                        <!-- Menampilkan surat_perizinan -->
                        <a href="{{ asset('storage/surat_perizinan/' . basename($formulir->surat_perizinan)) }}" target="_blank">
                            Lihat Surat Perizinan
                        </a>
                    </td>
                    <td>
                        <!-- Menampilkan gambar -->
                        <img src="{{ asset('storage/images/' . basename($formulir->gambar)) }}" alt="Gambar" style="max-width: 100px;">
                    </td>
                    <td>{{ $formulir->status }}</td>
                    <td>
                        <!-- Menampilkan file download -->
                        <a href="{{ asset('storage/download/' . basename($formulir->download)) }}" target="_blank">
                            Download
                        </a>
                    </td>
                    
                    <td>
                        <!-- Aksi untuk Create dan Edit -->
                        <a href="{{ route('admin.progres.edit', $formulir->id) }}" class="btn btn-primary">Edit Progres</a>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
@endsection
