@extends('layouts.app')

@section('title', 'Data')

@section('content')
<head>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.6/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.3.0/js/dataTables.buttons.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/2.3.0/css/buttons.dataTables.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.3.0/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.3.0/js/buttons.print.min.js"></script>
</head>
<div class="container-fluid custom-background">
    <div class="container">
        <h1>Data Situs Bersejarah</h1>

        <a href="{{ route('data.download') }}" class="btn btn-primary">Unduh Data</a>

        <table class="table table-striped table-bordered" id="yourTableId">
            <thead>
                <tr>
                    <th>ID Situs</th>
                    <th>Nama Situs</th>
                    <th>Alamat Situs</th>
                    <th>Tanggal Berdiri</th>
                    <th>Pemilik</th>
                    <th>Jenis</th>
                    <th>Status</th>
                    <th>Keterangan</th>
                </tr>
            </thead>
            <tbody>
                @foreach($data as $item)
                    <tr>
                        <td>{{ $item->id_situs }}</td>
                        <td>{{ $item->nama_situs }}</td>
                        <td>{{ $item->alamat_situs }}</td>
                        <td>{{ $item->tanggal_berdiri_situs }}</td>
                        <td>{{ $item->pemilik_situs }}</td>
                        <td>{{ $item->jenis }}</td>
                        <td>{{ $item->status_situs }}</td>
                        <td>{{ Str::limit($item->keterangan_situs, 5) }}</td>

                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@include('layouts.footer')
@endsection
<style>
    .custom-background {
        background-color: #DBCAB5;
        min-height: 100vh;
        padding: 20px;
    }
    .carousel-item {
    border-radius: 20px;
    overflow: hidden;
    }

</style>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.11.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.3.0/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.3.0/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.3.0/js/buttons.print.min.js"></script>
<script>
    $(document).ready(function () {
        $('#yourTableId').DataTable({
            dom: 'Bfrtip',
            buttons: [
                'copy', 'csv', 'excel', 'pdf', 'print'
            ]
        });
    });
</script>
