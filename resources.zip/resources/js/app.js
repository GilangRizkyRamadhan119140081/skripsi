// // app.js
// import './bootstrap';
require('./bootstrap');

// Anda dapat menambahkan kode JavaScript tambahan di sini
